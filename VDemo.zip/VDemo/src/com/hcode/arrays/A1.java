package com.hcode.arrays;

import java.util.Arrays;

public class A1 {
	
	public static void main(String[] args) {
		int[] a = {1,2,3,4,5};
		
		rotLeft2(a, 2);
		
	}
	
	static int[] rotLeft(int[] a, int d) {
		while(d > 0) {
			int temp =a[0];
			for(int i=0; i < a.length-1; i++) {
				a[i] = a[i+1];
			}
			
			a[a.length-1] = temp;
			--d;
		}
		
		return a;
	}
	
	static int[] rotLeft2(int[] a, int d) {
		int[] newArray = new int[a.length];
		for (int i=0; i < a.length; i++) {
			int newIndex = (i + d) % a.length;
			newArray[i] = a[newIndex];
		}
		System.out.println(Arrays.toString(newArray));
		return newArray;
	}

}
