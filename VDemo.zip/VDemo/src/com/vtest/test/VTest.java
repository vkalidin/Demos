package com.vtest.test;

public class VTest {
	
	public static void main(String[] args) {
		//string aabcccccaaa would becomes a2blc5a3.
		String input = "aabccccaaad";
		
		char prev = input.charAt(0); //a
		String output = "";
		int j=1;
		
		for (int i=1; i < input.length(); ++i) {
			if(prev == input.charAt(i)) {
				++j;
			}else {
				output = output + prev + j;
				prev = input.charAt(i);
				j=1;
			}
			
		}
		
		output = output + prev + j;
		System.out.println(output);
	}

}
