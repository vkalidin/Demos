package com.vtest.string;

import org.junit.Test;

public class Test1 {
	
	public int fac(int n) {
		int result;
		
		if (n ==1) {
			return 1;
		}
		
		result = n*fac(n-1);
		return result;
	}
	
	
	public int fib(int n) {
		System.out.println(n);
		if ( n<=1) {
			return n;
		}
		
		return fib(n-1) + fib(n-2);
	}
	
	//most optimized
		public int fib_opt(int n) {
			int a=0, b=1, c=0;
			
			if (n<=1) {
				return n;
			}
			
			for(int i =2; i<=n; i++) {
				System.out.println(c + ",");
				c = a + b;
				a = b;
				b = c;
			}
			return b;
			
		}
	
	
	@Test
	public void t1() {
		//int x = fac(3);
		//System.out.println(x);
		System.out.println(3 % 4);
		//int x = fib_opt(6);
		//System.out.println("x=" + x);
		//System.out.println(5 % 10);
	}
}
