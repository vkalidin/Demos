package com.vtest.string;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class StringUtil {
	
	/** USING STRING BUILDER **/
	public String strReverse(String str) {
		return new StringBuilder(str).reverse().toString();
	}
	
	/** USING CHAR ARRAY **/
	public String strReverseUsingChar(String str) {
		char[] c = str.toCharArray();
		String reverse = "";
		for (int i=c.length-1; i >= 0; i--) {
			reverse = reverse + c[i];
		}
		
		return reverse;
	}
	
	/**WITHOUT USING CHAR ARRAY **/
	public String strReverseUsingChar2(String str) {
		String reverse = "";
		for (int i=str.length()-1; i >= 0; i--) {
			reverse = reverse + str.charAt(i);
		}
		
		return reverse;
	}
	
	@Test
	public void test1() {
		//String val = this.strReverseUsingChar2("THIS IS NICE WORK!");
		
		//System.out.println(val);
		
		String x = "abcxyz";
		//System.out.println(x.substring(0,1));
		//dupCharInString("aabccxyzz");
		breakStringBasedOnDelimiter("This is a test, first, last");
	}
	
	public void dupCharInString(String input) {
		char[] ch = input.toCharArray();
		
		Map<Character, Integer> occCount = new HashMap<Character, Integer>();
		
		for (char c : ch) {
			if (occCount.containsKey(c)) {
				occCount.put(c, occCount.get(c)+1);
			}else {
				occCount.put(c, 1);
			}
		}
		
		for (Object mp : occCount.keySet()) {
			System.out.println(mp + "-->" + occCount.get(mp));
		}
		
	}
	
	
	public void breakStringBasedOnDelimiter(String input) {
		String dummy = "This is a  test,first";
		String[] temp = input.split(",");
		ArrayList<String> outLst = new ArrayList<String>();
		
		for(int i=0; i < temp.length; i++) {
			for(int j=0; j < temp[i].split("\\s+").length; j++) {
				if(!temp[i].split("\\s+")[j].isEmpty())
					outLst.add(temp[i].split("\\s+")[j].trim());
			}
		}
		
		System.out.println(outLst);
	}
	
	

}
