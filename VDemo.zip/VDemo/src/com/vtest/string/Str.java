package com.vtest.string;

import java.util.HashMap;
import java.util.Map;

public class Str {

	public static void main(String[] args ) {
		//System.out.println(printDuplicateCharCount("strriingg"));
		printDuplicateCharCount("ssttrrrrr");
	}
	
	public static String subString(String input, String delimiter) {
		
		String output = input.valueOf("n");
		return output;
		
	}
	
	//longest subString witout repeating chars
	public static int longSubString(String s) {
		int n = s.length(), ans=0;
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		
		for (int j=0, i=0; j < n; j++) {
			if (map.containsKey(s.charAt(j))) {
				i = Math.max(map.get(s.charAt(j)), i);
			}
			
			ans = Math.max(ans, j-i+1);
			map.put(s.charAt(j), j+1);
		}
		
		return ans;
	}
	
	//find out DUPLICATE characters in a string
	public static void printDuplicateCharCount(String input) {
		
		char[] a = input.toCharArray();
		Map<Character, Integer> dupMap = new HashMap<Character, Integer>();
		
		// constructing map (key, value) per char and its occurance
		for(Character ch:a) {
			if(dupMap.containsKey(ch)) {
				dupMap.put(ch, dupMap.get(ch)+1);
			}else
				dupMap.put(ch,1);
		}
		
		for (Object key : dupMap.keySet()) {			
			System.out.println(key + "--->" + dupMap.get(key));
		}
	}
	
	
	
}

