package com.vtest.polymorphism;

public class Demo {
	
	public static void main(String[] args) {
		Employee emp = new Manager();
		String cName = emp.getClass().getName().toString();
		//System.out.println(cName);
		
		emp.name();
	}


}
