package com.vtest.polymorphism;

public class Employee {
	
	public void name() {
		System.out.println("This is Employee.name()");
	}

}
