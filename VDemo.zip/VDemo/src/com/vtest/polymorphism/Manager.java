package com.vtest.polymorphism;

public class Manager extends Employee {
	
	public void name ( ) {
		System.out.println("This is Manager.name()");
	}
	
}

