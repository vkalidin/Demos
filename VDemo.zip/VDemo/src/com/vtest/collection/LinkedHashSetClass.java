package com.vtest.collection;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class LinkedHashSetClass {
	
	public static void main(String[] args) {
		LinkedHashSet<String> lhm = new LinkedHashSet<String>();
		
		lhm.add("Bananas");
		lhm.add("Apples");
		lhm.add("Apples");
		lhm.add(null);
		
		for (Object o : lhm) {
			System.out.println(o);
		}
		
		
		
		
	}

}
