package com.vtest.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class HashMapClass {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		
		hm.put(1, "Value_1");
		hm.put(2, "Value_2");
		hm.put(null, null); //permits null KEY and VALUE
		
		System.out.println(hm.size());
		System.out.println(hm.values());
		
		System.out.println(hm);
		
		//hm.remove(1);
		System.out.println(hm.get(null));
		
		for (Object m : hm.entrySet()) {
			System.out.println(m);
		}
		
		Iterator iterator = hm.entrySet().iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		
		
	}

}
