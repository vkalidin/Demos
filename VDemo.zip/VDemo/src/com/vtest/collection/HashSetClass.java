package com.vtest.collection;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetClass {

	public static void main(String[] args) {
		HashSet<String> hs = new HashSet<String>();
		
		hs.add("Apple");
		hs.add("Banana");
		hs.add(null);
		hs.add("Apple");
		hs.add(null);
		
		System.out.println(hs);
		
		Iterator iterator = hs.iterator();
		
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		for (Object o : hs)
			System.out.println(o);
	}
}
