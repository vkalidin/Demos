package com.vtest.collection;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class TreeMapClass {
	
	public static void main(String[] args) {
		
		TreeMap<Integer, String> tm = new TreeMap<Integer, String>();
		
		tm.put(1, "Value_1");
		tm.put(22, "Value_22");
		tm.put(5, "Value_5");
		tm.put(2, "Value_2");
		tm.put(3, null);

		
		System.out.println(tm);
		
		Iterator iterator = tm.entrySet().iterator();
		
		for (Object o : tm.entrySet()) {
			String[] s = o.toString().split("=", o.toString().length());
			System.out.println(s[0] + "---->" + s[1]);
		}
		
		while(iterator.hasNext()) {
			Map.Entry me = (Entry) iterator.next();
			System.out.println(me.getKey() + "-->" + me.getValue());
		}
		
	}

}
