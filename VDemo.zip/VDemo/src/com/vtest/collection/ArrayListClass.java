package com.vtest.collection;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class ArrayListClass {
	
	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		
		al.add("Element_1");
		al.add("Element_2");
		al.add(null);
		
		System.out.println("ArrayList collection is: " + al);
		
		System.out.println(al.get(0));
		
		System.out.println(al.size());
		
		al.add(1, "Element_x");
		al.remove(1);
		
		String[] arr = new String[al.size()];
		arr = al.toArray(arr);
		
		String sum = "";
		for (String a : arr) {
			System.out.println(a);
			sum = sum + a;
		}
		
		System.out.println(sum);
	}

}
