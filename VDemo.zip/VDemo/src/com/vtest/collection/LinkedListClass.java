package com.vtest.collection;

import java.util.LinkedList;

public class LinkedListClass {
	
	public static void main(String[] args) {
		LinkedList<String> ll = new LinkedList<String>();
		LinkedList<String> ll_rev = new LinkedList<String>();
		
		ll.add("v1");
		ll.add("v2");
		ll.add("v3");
		
		
		//System.out.println(ll.get(2));
		for (int i=ll.size()-1; i>=0; i--) {
			ll_rev.add(ll.get(i));
		}
		
		//System.out.println("Reverse = " + ll_rev);
		
		reverseTrick();
	}
	
	public static void reverseTrick() {
		LinkedList<String> ll = new LinkedList<String>();
		ll.add("v0");
		ll.add("v1");
		ll.add("v2");
		ll.add("v3");
		ll.add("v4");
		ll.add("v5");
		//ll.add("v6");
		
		System.out.println(ll);
		
		String temp = "";
		
		for (int i=0; i<ll.size()/2; i++) {
			temp = ll.get(ll.size()-1-i); //last element
			ll.set(ll.size()-1-i, ll.get(i));
			ll.set((i), temp);
		}
		
		System.out.println(ll);
	}
	

}
