package com.vtest.main;

public class Fib {
	
	public static void main(String[] args) {
		System.out.println(fib_opt(9));
	}
	
	
	//using recursion - time complexity is exponential
	public static int fib_rec(int n) {		
		if (n <=1) {
			return n;
		}
		return fib_rec(n-1) + fib_rec(n-2);
		
	}
	
	//using dynamic programming - time complexity is O(n)
	public static int fib_dyn(int n) {
		
		int f[] = new int[n+1];
		f[1] = 1;
		f[0] = 0;
		
		for(int i=2; i<=n; i++) {
			f[i] = f[i-1] + f[i-2];			
			System.out.println("f["+i+"]="+f[i]);

		}
		
		return f[n];
	}
	
	//most optimized
	public static int fib_opt(int n) {
		int a=0, b=1, c=0;
		
		if (n<=1) {
			return n;
		}
		
		for(int i =2; i<=n; i++) {
			System.out.println(c + ",");
			c = a + b;
			a = b;
			b = c;
		}
		return b;
		
	}
	
	
}

