package com.vtest.main;

public class ClassA {
	
	int x = 3;
    int y;
    // instance initialization code
    {
        y = x * 2;
        System.out.println(y);
    }

    // static initialization code
    static {
        System.out.println("Static initialization");
    }


}
