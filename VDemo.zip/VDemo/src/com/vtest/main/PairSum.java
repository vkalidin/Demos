package com.vtest.main;

import java.util.Arrays;

public class PairSum {
	
	static int[] a = {1,1,3,3,5,5,7,2,6,0,8};
	
	public static void main(String[] args) {
		pairSumSorting(a, 8);
		//pairSum_2(a, 8);
	}
	
	
	public static void pairSumSorting(int[] a, int sum) {
		
		//sort the array in increasing order
		//int[] temp;
		Arrays.sort(a);
		int l=0, r = a.length-1;
		
		while (l < r) {
			if (a[l] + a[r] == sum) {
			
				System.out.println("["+a[l]+","+a[r]+"]");
				l++;
				//r--;
			}
			else if (a[l] + a[r] < sum)
				l++;
			else r--;
		}
	}
	
	public static void pairSum_2(int[] a, int sum) {
		int[] output;
		
		for(int i=0; i < a.length; i++) {
			for (int j=i+1; j<a.length; j++) {
				if ((a[i] + a[j]) == sum) {
					System.out.println("[" + a[i] + " , " + a[j]);
				}
			}
		}
		
	}

}
