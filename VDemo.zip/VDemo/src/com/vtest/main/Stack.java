package com.vtest.main;

public class Stack {
	
	int[] stk = new int[10];
	int tos = -1;
	
	void push(int item) {
		if (tos == 9) {
			System.out.println("Stack is full.");
		} else {
			stk[++tos] = item;
		}
	}
	
	int pop( ) {
		if (tos < 0) {
			System.out.println("Stack is underflowing.");
			return 0;
		}else
			return stk[tos--];
	}
	
	public static void main(String[] args) {
		Stack stk = new Stack();
		stk.push(1);
		stk.push(2);
		System.out.println(stk.pop());
	}

}
