package com.vtest.main;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.Test;

public class ArraySort {
	
	//@Test
	public void arrayBubbleSort( ) {
		int[] a = new int[] {2,4,1,3,5,9,7,2};
		int temp;
		
		//System.out.println(a.length);
		boolean swap;
		//sorting array with duplicates
		for (int i=0; i<a.length; i++) {
			swap = false;
			for (int j=0; j<a.length-1; j++) {
				if (a[j] < a[j+1]) { //4,2,1,3,5,9,7,2
					temp = a[j];
					a[j] = a[j+1];
					a[j+1] = temp;	
					swap=true;
				}
			}
			
			if (swap == false) {
				break;
			}
		}
		
		for (int i : a) {
			System.out.println(i);
		}
	}
	
	@Test
	public void test_arrays() {
		Integer a[] = {2,5,1,3,6};
		Arrays.sort(a, Collections.reverseOrder());
		for (int x : a) System.out.println(x);
	}
	
	@Test
	public void test_multidimentional_reverse() {
		
		Integer a[][] = new Integer[][] {
			{1,3,2},
			{0,3,1}
		};
		
		for (int i=0;i < 2; i++) {
			for (int j=0; j < 3; j++) {
				a[i][j] = a[i][j] + 1;
			}
		}
		
		for (int i = 0; i < 2; i++) {
            System.out.println(Arrays.toString(a[i]));
        }

		
		
		
	}

}
