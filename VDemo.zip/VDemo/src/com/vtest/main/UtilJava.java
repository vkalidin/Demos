package com.vtest.main;

public class UtilJava {
	
	public static void main(String[] rgs) {
		
		String x = new String("abc");
		String y = new String("abc");
		
		if (x==(y) ) {
			System.out.println("TRUE");
		}
	}
	

}
	