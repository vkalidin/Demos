package com.vtest.main;

public class Queue {

	int[] qu = new int[10];
	int pos = -1;
	
	void insert(int item) {	
		if(pos < qu.length) {
			qu[++pos] = item;
		}else {
			System.out.println("Queue is filled up.");
		}
		
	}
	
	int peek(int item) {
		if (pos >= 0) {
			return qu[0];
		}else {
			System.out.println("Queue is empty");
			return -1;
		}
		
	}
	
	int delete(int item) {
		if (pos >= 0) {
			
		}else {
			System.out.println("Queue is empty");
			return -1;
		}
		return -1;
		
	}
	
	
	
}
