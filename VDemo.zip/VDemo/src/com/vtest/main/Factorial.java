package com.vtest.main;

public class Factorial {
	
	int fact(int n) {
		int result;
		
		if(n ==1) {
			return 1;
		}
		
		result = n*fact(n-1);
		return result;
	}
	
	public static void main(String[] args) {
		Factorial f = new Factorial();
		int val = f.fact(5);
		System.out.println(val);
	}

}
