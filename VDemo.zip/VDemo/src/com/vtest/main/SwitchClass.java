package com.vtest.main;

public class SwitchClass {

	public static void main(String[] args) {

		int i = 15;
		switch (i) {

		case 1:
			System.out.println("1");
			break;
		case 5:
			System.out.println("5");
			break;
		default:
			System.out.println("DEFAULT");

		}
		
		printEven(0,5);

	}

	public static void printEven(int a, int b) {
		
		for (int i=a; i<=b; i++) {
			
			if (i == 0) {
				System.out.println("0 is neither even nor odd.");
				continue;
			}
			
			if (i % 2 == 0) {
				System.out.println(i + " is even");
			}else
				System.out.println(i + " is odd");
			
		}

	}

}
