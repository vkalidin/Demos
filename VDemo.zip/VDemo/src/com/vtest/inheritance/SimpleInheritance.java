package com.vtest.inheritance;

public class SimpleInheritance {
	
	public SimpleInheritance() {
		System.out.println("Calling Parent constructor.");
	}
	
	void parent_method() {
		System.out.println("Parent Method");
	}
	
	
	public class SubClass extends SimpleInheritance {
		/*public SubClass() {
			super();
		}*/
		
		public void sub_method() {
			System.out.println("Sub class method");
		}
	}
	
	public static void main(String[] args) {
		//SimpleInheritance si = new SimpleInheritance();
		SubClass x= new SimpleInheritance().new SubClass();
		//x.parent_method();
	}

}


