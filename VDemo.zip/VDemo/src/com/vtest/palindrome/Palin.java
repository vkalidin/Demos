package com.vtest.palindrome;

public class Palin {
	
	public static void main(String[] args) {
		System.out.println(retPalindroneINT(9));
		//retPalindroneINT(123);
	}
	
	//palindrome without String builder
	public static Boolean isPalindrome(String value) {
		char a[] = value.toCharArray();
		//char a[] = String.valueOf(value).toCharArray();

		System.out.println("length of array is " + a.length);
		String output = "";
		
		for(int i=a.length-1; i>=0; i--  ) {
			output = output + a[i];
		}
		
		if ((value).equals(output)) {
			return true;
		} else return false;
		
	}
	
	//palindrome STRING logic using StringBuilder
	public static Boolean isPalindrome2(String value) {
		return value.equals(new StringBuilder(value).reverse().toString());
	}
	
	//palindrome - INT no conversion to String
	public static int retPalindroneINT(int x) {
		String value = "";

		if (x > 0) {
			int temp = x;
			while (temp > 0) {
				int digit = temp % 10;
				value = value + digit;
				temp = temp / 10;
			}
						
			
		}
		//System.out.println("value is "+ value);
		return Integer.parseInt(value);
			
	}
	
	

}
