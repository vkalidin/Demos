package com.vtest.palindrome;

import org.junit.Test;

public class IsPalindrome {
	
	/** USING STRING BUILDER **/
	public void isPalindrome (String str) {
		if (str.equals(new StringBuilder(str).reverse().toString())) {
			System.out.println("This is palindrome!");
		}
	}
	
	
	public boolean isPalindrome2(String str) {
		//char[] a = str.toCharArray();
		boolean returnVal = false;
		String newStr = str.replaceAll("\\s+","");
		
		for (int i=0; i < (newStr.length() / 2); i++) {
			System.out.println(String.valueOf(newStr.charAt(i)).toLowerCase() + "-->" + String.valueOf(newStr.charAt(newStr.length()-1-i)).toLowerCase());
			if (String.valueOf(newStr.charAt(i)).toLowerCase().equals(String.valueOf(newStr.charAt(newStr.length()-1-i)).toLowerCase())) {
				returnVal = true;
			}else {
				returnVal=false;
				break;
			}
		}
		
		return returnVal;
	}
	
	public boolean isPalindrome_toCharArray(String input) {
		char[] palArray = input.toCharArray();
		String output = "";
		
		for (int i=palArray.length-1; i>=0; i--) {
			output = output + palArray[i];
		}
		
		if ((input.replaceAll("\\s+", "")).equalsIgnoreCase(output.replaceAll("\\s+", ""))) {
			return true;
		}else return false;
	}
	
	/*public boolean isPalindrome(int input) {
		String value = "";
		if (input > 0) {
			int temp = input;
			while (temp > 0) {
				int digit = temp % 10;
				value = value + digit;
				temp = temp / 10;
			}
		}
		
		if (input == Integer.parseInt(value)) {
			return true;
		}else return false;
		
	}*/
	
	@Test
	public void test_2() {
		//System.out.println(new String('c'));
		//System.out.println(isPalindrome2("A Santa Lived As a Devil At NASA"));
		//System.out.println(isPalindrome_toCharArray("A Santa Lived As a Devil At NASA"));
		System.out.println(isPalindrome(12321));
		
	}

}
