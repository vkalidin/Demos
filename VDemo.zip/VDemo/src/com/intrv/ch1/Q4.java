package com.intrv.ch1;

import java.util.Arrays;

public class Q4 {

	static int[][] rotate(int[][] matrix) {
		int n = matrix.length;
		int[][] ret = new int[n][n];
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				ret[i][j] = matrix[n - 1 - j][i];
			}
		}
		return ret;
	}
	
	
	public static void main(String[] args) {
		 int[][] a = {{1, 2, 3, 4,5},
                 {11,22,33,44,55},
                 {5, 4, 3, 2, 1},
                 {55,44,33,22,11},
                 {6, 7, 8, 9, 0}};
		//Q4.rotate(a);
		 System.out.println(Arrays.deepToString(Q4.rotate(a)));
		//System.out.println(Arrays.toString(Q4.rotate(a)));
	}

}
