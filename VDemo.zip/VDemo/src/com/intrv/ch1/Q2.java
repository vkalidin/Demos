package com.intrv.ch1;

import java.util.Arrays;

/**
 * Given two strings, write a method to decide if one is a permutation of the other.
 * (Assume comparison is case-sensitive, space-significant, ASCII-based.)
 */
public class Q2 {
	
	boolean isStrPermutation(String s1, String s2) {
		
		boolean returnVal = true;
		
		char[] chSet1 = s1.toCharArray();
		char[] chSet2 = s2.toCharArray();
		
		Arrays.sort(chSet1);
		Arrays.sort(chSet2);
		
		String s1_bash = String.valueOf(chSet1);
		String s2_bash = String.valueOf(chSet2);
		
		if (s1_bash.equals(s2_bash))
			returnVal= true;
		else {
			returnVal = false;
		}
		
		return returnVal;
	}
	
	public static void main(String[] args) {
		Q2 q2 = new Q2();
		boolean returnVal = q2.isStrPermutation("bus", "sub");
		System.out.println("returnVal= " + returnVal);
	}

}
