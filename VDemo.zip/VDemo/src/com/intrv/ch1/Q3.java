package com.intrv.ch1;

public class Q3 {

	/**
	 * Implement a method to perform basic string compression using the counts of
	 * repeated characters. For example, the string aabcccccaaa would become
	 * a2blc5a3. If the "compressed" string would not become smaller than the original
	 * string, your method should return the original string.
	 */
	
	static boolean compress(String s) {
		char[] chSet = s.toCharArray();		
		String output = "";
		
		char prev = chSet[0];
		int j=1;
		
		for(int i=1; i < chSet.length; ++i) {
			if(prev == chSet[i]) {
				prev = chSet[i];
				++j;
			}else {
				output = output + String.valueOf(prev) + j;
				prev = chSet[i];
				j =1;	
			}
		}
		
		output = output + String.valueOf(prev) + j;
		
		return true;
		
	}
	
	public static void main(String[] args) {
		Q3.compress("aabcccccaaad");
	}
}
