package com.intrv.ch1;

public class Q1 {
	
	/**
	 * Implement an algorithm to determine if a string has all unique characters. What
	 * if you cannot use additional data structures? (Assume string is ASCII based.)
	 */
	
	boolean hasAllUnique(String input) {
		if(input == null || input.isEmpty() || input.length() > 256) {
			return false;
		}
		
		
		boolean[] charSet = new boolean[256];
		
		for(int i=0; i < input.length(); i++) {
			char ch = input.charAt(i);
			
			if(charSet[ch]) return false;
			else charSet[ch] = true;
		}
		
		return true;
	}
	
	
	public static void main(String[] args) {
		Q1 q1 = new Q1();
		q1.hasAllUnique("thiss");
	}

}
