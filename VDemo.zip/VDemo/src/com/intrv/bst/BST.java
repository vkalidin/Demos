package com.intrv.bst;

public class BST {
	
	class Node {
		int value;
		Node left;
		Node right;
		
		Node(int x) {
			this.value = x;
			this.left = null;
			this.right = null;			
		}
		
		
		public class BinaryTree {
			
			Node root;
			
			
		}
	}

}
